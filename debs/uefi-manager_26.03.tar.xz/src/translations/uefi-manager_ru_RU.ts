<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>Administrator Access Required</source>
        <translation>Требуется доступ администратора</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="173"/>
        <source>This operation requires administrator privileges.</source>
        <translation>Для этой операции требуется права администратора.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Пожалуйста, выберите место установки:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Выберите диск:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Выберите раздел:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Экономный режим:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Параметры загрузки:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>Имя записи UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>Менеджер UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>Установщик заглушки EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Ядро для загрузки:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Параметры ядра:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Управление записями UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Эта опция копирует ядро и initrd файлы в ESP (EFI System Partition) и создаёт запись UEFI, которая позволяет загрузить установку напрямую, обходя GRUB и другие загрузчики. Чтобы загрузиться с помощью созданной записи UEFI, откройте меню выбора загрузки UEFI при запуске, нажав соответствующую клавишу для вашего устройства (например, F12, F9 или Esc, в зависимости от производителя).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>Низкоресурсный установщик EFI stub</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Эта опция предназначена для создания загрузочной записи для экономичной установки MX и antiX. Она создает загрузочную запись EFI для прямого запуска установки, минуя GRUB и другие загрузчики. Чтобы загрузиться с помощью созданной записи UEFI, откройте меню выбора загрузки UEFI при запуске, нажав соответствующую клавишу для вашего устройства (например, F12, F9 или Esc, в зависимости от производителя).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <location filename="../src/mainwindow.cpp" line="1769"/>
        <source>Next</source>
        <translation>Следующий</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="772"/>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <location filename="../src/mainwindow.cpp" line="1575"/>
        <location filename="../src/mainwindow.cpp" line="1585"/>
        <source>UEFI Installer</source>
        <translation>Установщик UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>Обнаружена недавняя ограниченная установка. Хотите добавить запись UEFI непосредственно в системное меню UEFI?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1018"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Не удалось получить UUID для %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1025"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Введите пароль для разблокировки зашифрованного раздела %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1030"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>Ввод парольной фразы отменен или пуст для %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1036"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Не удалось открыть %1 контейнер LUKS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1576"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>Вы уверены, что это место установки MX или antiX Frugal?
Отсутствуют обязательные файлы в каталоге:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1644"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>Недостаточно места на системном разделе EFI для копирования файлов ядра и initrd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>All fields are required</source>
        <translation>Все поля обязательны для заполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1729"/>
        <source>Could not select ESP</source>
        <translation>Не удалось выбрать ESP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1747"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>Select EFI file</source>
        <translation>Выберите файл EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>Файлы EFI (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <location filename="../src/mainwindow.cpp" line="190"/>
        <location filename="../src/mainwindow.cpp" line="1018"/>
        <location filename="../src/mainwindow.cpp" line="1030"/>
        <location filename="../src/mainwindow.cpp" line="1036"/>
        <location filename="../src/mainwindow.cpp" line="1791"/>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <location filename="../src/mainwindow.cpp" line="2000"/>
        <location filename="../src/mainwindow.cpp" line="2011"/>
        <location filename="../src/mainwindow.cpp" line="2018"/>
        <location filename="../src/mainwindow.cpp" line="2029"/>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <location filename="../src/mainwindow.cpp" line="2053"/>
        <location filename="../src/mainwindow.cpp" line="2058"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Не удалось найти исходную точку монтирования для %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Set name</source>
        <translation>Задать имя</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Введите имя для элемента меню UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <source>Selected file is not in an EFI directory</source>
        <translation>Выбранный файл не находится в каталоге EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="190"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Что-то пошло не так, не удалось добавить запись.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="802"/>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <location filename="../src/mainwindow.cpp" line="1806"/>
        <source>Timeout: %1 seconds</source>
        <translation>Таймаут: %1 с</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="804"/>
        <location filename="../src/mainwindow.cpp" line="844"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <location filename="../src/mainwindow.cpp" line="1823"/>
        <source>Boot Next: %1</source>
        <translation>Следующая загрузка: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="806"/>
        <source>Boot Current: %1</source>
        <translation>Текущая загрузка: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="820"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Вы можете использовать кнопки вверх/вниз или перетаскивание элементов, чтобы изменить порядок загрузки.
- Элементы перечислены в порядке загрузки.
- Выделенные серым цветом строки неактивны.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="831"/>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source>Set ac&amp;tive</source>
        <translation>Задать а&amp;ктивную</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="832"/>
        <source>&amp;Add entry</source>
        <translation>&amp;Добавить запись</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <source>Boot &amp;next</source>
        <translation>Следующая заг&amp;рузка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Move &amp;down</source>
        <translation>Сместить &amp;вниз</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="835"/>
        <source>&amp;Remove entry</source>
        <translation>&amp;Удалить запись</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="837"/>
        <source>Re&amp;set next</source>
        <translation>Сброс следую&amp;щей</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>Change &amp;timeout</source>
        <translation>См&amp;енить таймаут</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="839"/>
        <source>Move &amp;up</source>
        <translation>Сместить ввер&amp;х</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="844"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <source>not set, will boot using list order</source>
        <translation>не установлено, будет загружаться в соответствии с порядком списка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="891"/>
        <source>Set &amp;inactive</source>
        <translation>С&amp;делать неактивной</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Failed to open grub.entry file.</source>
        <translation>Не удалось открыть файл grub.entry.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1750"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Инструмент для управления загрузочными записями UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <source>Both old and new EFI labels must be specified</source>
        <translation>Необходимо указать как старые, так и новые метки EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2001"/>
        <source>Multiple boot entries found for label &apos;%1&apos;: %2 and %3;</source>
        <translation>Обнаружено несколько записей загрузки для метки &apos;%1&apos;: %2 и %3;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2011"/>
        <source>No EFI data found for label &apos;%1&apos;.</source>
        <translation>Данные EFI для метки &apos;%1&apos; не найдены.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2019"/>
        <source>EFI label &apos;%1&apos; is linked to an unknown partition &apos;%2&apos;.</source>
        <translation>Метка EFI &apos;%1&apos; связана с неизвестным разделом &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2030"/>
        <source>Unexpected device name format &apos;%1&apos; for partition related to the label.</source>
        <translation>Неожиданный формат имени устройства &apos;%1&apos; для раздела, связанного с меткой.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2040"/>
        <source>Device partition number [%1] differs from EFI entry partition number [%2].</source>
        <translation>Номер раздела устройства [%1] отличается от номера раздела записи EFI [%2].</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2053"/>
        <source>Failed to delete old boot entry</source>
        <translation>Не удалось удалить старую загрузочную запись.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2058"/>
        <source>Failed to create new boot entry</source>
        <translation>Не удалось создать новую загрузочную запись</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1585"/>
        <source>Failed to read grub.entry file.</source>
        <translation>Не удалось прочитать файл grub.entry.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="955"/>
        <location filename="../src/mainwindow.cpp" line="1598"/>
        <source>Install</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1604"/>
        <source>Select Frugal Directory</source>
        <translation>Выберите каталог экономичной установки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1611"/>
        <source>No EFI System Partitions found.</source>
        <translation>Разделы системы EFI не обнаружены.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1617"/>
        <source>Select EFI System Partition</source>
        <translation>Выберите раздел системы EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1618"/>
        <source>EFI System Partitions:</source>
        <translation>Разделы системы EFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1631"/>
        <source>No EFI System Partition selected</source>
        <translation>Раздел системы EFI не выбран</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1638"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>Не удалось смонтировать выбранный системный раздел EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1669"/>
        <location filename="../src/mainwindow.cpp" line="1713"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>Не удалось смонтировать раздел. Убедитесь, что вы выбрали правильный раздел.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1678"/>
        <source>No directory selected</source>
        <translation>Каталог не выбран</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <location filename="../src/mainwindow.cpp" line="1735"/>
        <source>EFI stub installed successfully.</source>
        <translation>Модуль EFI успешно установлен.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1700"/>
        <location filename="../src/mainwindow.cpp" line="1737"/>
        <source>Failed to install EFI stub.</source>
        <translation>Не удалось установить модуль EFI.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1748"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1752"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1753"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1761"/>
        <source>%1 Help</source>
        <translation>%1 Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1791"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Что-то пошло не так, не удалось сохранить порядок загрузки.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Set timeout</source>
        <translation>Задать таймаут</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Timeout in seconds:</source>
        <translation>Таймаут в секундах:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Removal confirmation</source>
        <translation>Подтверждение удаления</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1842"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Уверены, что хотите удалить эту загрузочную запись?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="125"/>
        <source>Error: Changelog file is missing.</source>
        <translation>Ошибка: Отсутствует файл журнала изменений.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="127"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>Ошибка: Отсутствует необходимая утилита &apos;zless&apos;.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>uefi-manager — это инструмент для управления загрузочными записями UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation>Для экономичной установки выполните установку модуля EFI.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>Менеджер UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation>Запустите в тестовом режиме (отключите определение UEFI для тестирования графического интерфейса).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>Похоже, эта система не поддерживает UEFI или не была загружена в режиме UEFI. Выход.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Программа запущена суперпользователем. Для использования программы войдите в систему как обычный пользователь.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>версия:</translation>
    </message>
</context>
</TS>