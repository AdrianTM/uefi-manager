<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>Administrator Access Required</source>
        <translation>Zahtevan je skrbniški dostop</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="173"/>
        <source>This operation requires administrator privileges.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Izberite mesto za namestitev:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Izberite pogon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Izberite razdelek:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Vtiki način:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Zagonske možnosti:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>Ime UEFI vnosa:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>UEFI upravljalnik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>Namestilnik EFI škrbine</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Jedro za zagon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Možnosti jedra:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Zapri aplikacijo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Prikaži pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Upravljanje UEFI vnosov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>Namestilnik vitke EFI škrbine</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <location filename="../src/mainwindow.cpp" line="1769"/>
        <source>Next</source>
        <translation>Naprej</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Nazaj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="772"/>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <location filename="../src/mainwindow.cpp" line="1575"/>
        <location filename="../src/mainwindow.cpp" line="1585"/>
        <source>UEFI Installer</source>
        <translation>UEFI namestilnik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>Zaznana je bila nedavna vtika namestitev. Ali želite dodati UEFI vnos neposredno v vaš UEFI meni?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1018"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Za %1 ni mogoče pridobiti UUID</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1025"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Vnesite geslo za odklep %1 šifriranih razdelkov:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1030"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>Vnos gesla je bil prekinjen ali prazen za %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1036"/>
        <source>Could not open %1 LUKS container</source>
        <translation>LUKS zabojnika %1 ni bilo mogočer odpreti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1576"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>Ali ste prepričani, da je to pravilna lokacija MX ali antiX vtike namestitve?
V mapi manjkajo obvezne datoteke:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1644"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>Na EFI sistemskem razdelku ni dovolj prostora za kopiranje jedra in initrd datotek.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>All fields are required</source>
        <translation>Vsa polja so obvezna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1729"/>
        <source>Could not select ESP</source>
        <translation>ESP ni bilo mogoče izbrati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1747"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>Select EFI file</source>
        <translation>Izberite EFI datoteko</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>EFI datoteke (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <location filename="../src/mainwindow.cpp" line="190"/>
        <location filename="../src/mainwindow.cpp" line="1018"/>
        <location filename="../src/mainwindow.cpp" line="1030"/>
        <location filename="../src/mainwindow.cpp" line="1036"/>
        <location filename="../src/mainwindow.cpp" line="1791"/>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <location filename="../src/mainwindow.cpp" line="2000"/>
        <location filename="../src/mainwindow.cpp" line="2011"/>
        <location filename="../src/mainwindow.cpp" line="2018"/>
        <location filename="../src/mainwindow.cpp" line="2029"/>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <location filename="../src/mainwindow.cpp" line="2053"/>
        <location filename="../src/mainwindow.cpp" line="2058"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Priklopne točke vira za %1 ni bilo mogoče najti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Set name</source>
        <translation>Določi ime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Vnesite ime za UEFI predmet menija:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <source>Selected file is not in an EFI directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="190"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Nekaj je šlo narobe. Vnosa ni bilo mogoče dodati.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="802"/>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <location filename="../src/mainwindow.cpp" line="1806"/>
        <source>Timeout: %1 seconds</source>
        <translation>Časovna omejitev: %1 sekund</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="804"/>
        <location filename="../src/mainwindow.cpp" line="844"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <location filename="../src/mainwindow.cpp" line="1823"/>
        <source>Boot Next: %1</source>
        <translation>Naslednji zagon: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="806"/>
        <source>Boot Current: %1</source>
        <translation>Trenutni zagon: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="820"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Lahko uporabite tipke gor/dol ali vlečete in spustite predmete, da spremenite zagonsko zaporedje.
- Predmeti so navedeni po vrstnem redu zagona.
- Osivele vrstice niso aktivne.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="831"/>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source>Set ac&amp;tive</source>
        <translation>Določi za akt&amp;ivno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="832"/>
        <source>&amp;Add entry</source>
        <translation>Dod&amp;aj vnos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <source>Boot &amp;next</source>
        <translation>&amp;Naslednji zagon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Move &amp;down</source>
        <translation>Premakni &amp;dol</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="835"/>
        <source>&amp;Remove entry</source>
        <translation>Odst&amp;rani vnos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="837"/>
        <source>Re&amp;set next</source>
        <translation>Pona&amp;stavi naslednjega</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>Change &amp;timeout</source>
        <translation>Spremeni &amp;časovno omejitev</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="839"/>
        <source>Move &amp;up</source>
        <translation>Premakni &amp;gor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="844"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <source>not set, will boot using list order</source>
        <translation>ni določen. Zagon bo potekal po seznamu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="891"/>
        <source>Set &amp;inactive</source>
        <translation>Določi za neakt&amp;ivno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Failed to open grub.entry file.</source>
        <translation>Napaka pri odpiranju grub.entry datoteke.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1750"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Orodje za upravljanje UEFI zagonskih vnosov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <source>Both old and new EFI labels must be specified</source>
        <translation>Podani morata biti tako stara, kot nova EFI oznaka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2001"/>
        <source>Multiple boot entries found for label &apos;%1&apos;: %2 and %3;</source>
        <translation>Za oznako &apos;%1&apos;:%2 in %3 je bilo najdenih več vnosov;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2011"/>
        <source>No EFI data found for label &apos;%1&apos;.</source>
        <translation>Za oznako &apos;%1&apos; ni bilo najdenih podatkov.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2019"/>
        <source>EFI label &apos;%1&apos; is linked to an unknown partition &apos;%2&apos;.</source>
        <translation>EFI oznaka &apos;%1&apos; je povezana z neznanim razdelkom &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2030"/>
        <source>Unexpected device name format &apos;%1&apos; for partition related to the label.</source>
        <translation>Nepričakovana oblika zapisa imena naprave &apos;%1&apos; za razdelek, ki je povezan z oznako.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2040"/>
        <source>Device partition number [%1] differs from EFI entry partition number [%2].</source>
        <translation>Številka razdelka naprave [%1] se razlikuje od številke razdelke EFI vnosa [%2].</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2053"/>
        <source>Failed to delete old boot entry</source>
        <translation>Napaka pri odstranjevanju starega zagonskega vnosa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2058"/>
        <source>Failed to create new boot entry</source>
        <translation>Napaka pri ustvarjanju novega zagonskega vnosa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1585"/>
        <source>Failed to read grub.entry file.</source>
        <translation>Napaka pri branju grub.entry datoteke.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="955"/>
        <location filename="../src/mainwindow.cpp" line="1598"/>
        <source>Install</source>
        <translation>Namesti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1604"/>
        <source>Select Frugal Directory</source>
        <translation>Izberite mapo za vitko namestitev</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1611"/>
        <source>No EFI System Partitions found.</source>
        <translation>Noben EFI sistemski razdelek ni bi najden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1617"/>
        <source>Select EFI System Partition</source>
        <translation>Izberite EFI sistemski razdelek</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1618"/>
        <source>EFI System Partitions:</source>
        <translation>EFI sistemski razdelki:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1631"/>
        <source>No EFI System Partition selected</source>
        <translation>Noben EFI sistemski razdelek ni izbran</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1638"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>Izbranega EFI sistemskega razdelka ni bilo mogoče priklopiti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1669"/>
        <location filename="../src/mainwindow.cpp" line="1713"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>Razdelka ni bilo mogoče priklopiti. Prepričajte se, da ste izbrali pravi razdelek.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1678"/>
        <source>No directory selected</source>
        <translation>Noben imenik ni izbran</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <location filename="../src/mainwindow.cpp" line="1735"/>
        <source>EFI stub installed successfully.</source>
        <translation>EFI škrbina je bila uspešno nameščena.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1700"/>
        <location filename="../src/mainwindow.cpp" line="1737"/>
        <source>Failed to install EFI stub.</source>
        <translation>Napaka pri namestitvi EFI škrbine.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1748"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1752"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Avtorska zaščita (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1753"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1761"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1791"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Nekaj je šlo narobe. Zagonskega zaporedja ni bilo mogoče dodati.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Set timeout</source>
        <translation>Določi časovno omejitev</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Timeout in seconds:</source>
        <translation>Časovna omejitev v sekundah</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Removal confirmation</source>
        <translation>Potrjevanje odstranitve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1842"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Ali ste prepričani, da želite ta zagonski vnos?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="125"/>
        <source>Error: Changelog file is missing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="127"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>uefi-manager je orodje za upravljanje UEFI zagonskih vnosov</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation>Izvedi namestitev EFI škrbine za vitko namestitev.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>UEFI upravljalnik</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>Ta sistem nima podpore za UEFI ali ni bil zagnan v UEFI načinu. Končujem.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Prijavljeni ste kot korenski (root) uporabnik. Odjavite se in se ponovno prijavite kot običajen uporabnik, če želite uporabljati ta program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>različica:</translation>
    </message>
</context>
</TS>