<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sq">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="172"/>
        <source>Administrator Access Required</source>
        <translation>Lyp Hyrje Përgjegjësi</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="173"/>
        <source>This operation requires administrator privileges.</source>
        <translation>Ky veprim lyp privilegje përgjegjësi</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Ju lutemi, përzgjidhni vendndodhjen e instalimit tuaj:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Përzgjidhni disk:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Përzgjidhni pjesë:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Mënyra e Përkorë:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Mundësi nisjeje:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>Emër zëri UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>Përgjegjës UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Kernel për t’u nisur:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Mundësi kerneli:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>Mbi këtë aplikacion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>Mbi…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Mbylle aplikacionin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Mbylle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Shfaq ndihmë </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Administroni zëra UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Kjo mundësi kopjon kernelin dhe kartelat initrd te PSE (Pjesë Sistemi EFI) dhe krijon një zë UEFI që lejon të niset instalimi drejtpërsëdrejti, duke anashkaluar GRUB-in dhe të tjerë ngarkues nisjeje. Që të bëhet nisja duke përdorur zërin e krijuar UEFI, hyni në menunë e përzgjedhjes së nisjeve UEFI, gjatë nisjes, duke shtypur tastin e përshtatshëm për pajisjen tuaj (p.sh., F12, F9, ose Esc, varet nga prodhuesi i pajisjes).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Kjo mundësi është menduar për krijimin e një zëri të nisshëm për instalim të përkorë të MX-it dhe antiX-it, krijon një zë EFI nisjeje për nisje instalimi drejtpërdrejti, duke anashkaluar GRUB-in dhe të tjerë ngarkues nisjesh. Që ta nisni duke përdorur zërin UEFI të krijuar, kaloni gjatë fillimit te menuja e përzgjedhjes së nisjes UEFI, duke shtypur tastin e duhur për pajisjen tuaj (p.sh., F12, F9, ose Esc, varet nga prodhuesi).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Ndihmë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <location filename="../src/mainwindow.cpp" line="1769"/>
        <source>Next</source>
        <translation>Pasuesi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Mbrapsht</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="772"/>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <location filename="../src/mainwindow.cpp" line="1575"/>
        <location filename="../src/mainwindow.cpp" line="1585"/>
        <source>UEFI Installer</source>
        <translation>Instalues UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>Është pikuar një instalim i përkorë i freskët. Doni të shtohet një zë UEFI drejt e te menuja UEFI e sistemit tuaj?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1018"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>S’u mor dot UUID për %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1025"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Jepni frazëkalimin për të shkyçur pjesën e fshehtëzuar %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1030"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>Zë frazëkalimi i anuluar, ose i zbrazët për %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1036"/>
        <source>Could not open %1 LUKS container</source>
        <translation>S’u hap dot kontejner LUKS %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1576"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>Jeni i sigurt se kjo është vendndodhja e instalimit të Përkorë MX ose antiX?
Në drejtori mungojnë kartela të detyrueshme: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1644"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>Hapësirë e pamjaftueshme në Pjesë EFI Sistemi për kopjim të kartelave kernel dhe initrd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>All fields are required</source>
        <translation>Janë të domosdoshme krejt fushat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1729"/>
        <source>Could not select ESP</source>
        <translation>S’u përzgjodh dot ESP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1747"/>
        <source>About %1</source>
        <translation>Mbi %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>Select EFI file</source>
        <translation>Përzgjidhni kartelë EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="148"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>Kartela EFI (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <location filename="../src/mainwindow.cpp" line="190"/>
        <location filename="../src/mainwindow.cpp" line="1018"/>
        <location filename="../src/mainwindow.cpp" line="1030"/>
        <location filename="../src/mainwindow.cpp" line="1036"/>
        <location filename="../src/mainwindow.cpp" line="1791"/>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <location filename="../src/mainwindow.cpp" line="2000"/>
        <location filename="../src/mainwindow.cpp" line="2011"/>
        <location filename="../src/mainwindow.cpp" line="2018"/>
        <location filename="../src/mainwindow.cpp" line="2029"/>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <location filename="../src/mainwindow.cpp" line="2053"/>
        <location filename="../src/mainwindow.cpp" line="2058"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <location filename="../src/mainwindow.cpp" line="171"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>S’u gjet dot pikë montimi burimi për %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Set name</source>
        <translation>I vini emër</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Jepni emrin për zërin e menusë UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <source>Selected file is not in an EFI directory</source>
        <translation>Kartela e përzgjedhur s’është një drejtori EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="190"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Diç shkoi ters, s’u shtua dot zëri.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="802"/>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <location filename="../src/mainwindow.cpp" line="1806"/>
        <source>Timeout: %1 seconds</source>
        <translation>Mbarim kohe: %1 sekonda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="804"/>
        <location filename="../src/mainwindow.cpp" line="844"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <location filename="../src/mainwindow.cpp" line="1823"/>
        <source>Boot Next: %1</source>
        <translation>Nis Pasuesin: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="806"/>
        <source>Boot Current: %1</source>
        <translation>Nis të Tanishmin: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="820"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Që të ndryshoni rendin e nisjes, mund të përdorni butonat Sipër/Poshtë, ose të merrni &amp; lini zëra.
- Zërat paraqiten te rendi i nisjes.
- Rreshtat e paraqitur me gri janë joaktivë.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="831"/>
        <location filename="../src/mainwindow.cpp" line="894"/>
        <source>Set ac&amp;tive</source>
        <translation>Kaloje ak&amp;tiv</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="832"/>
        <source>&amp;Add entry</source>
        <translation>Shtoni &amp;zë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <source>Boot &amp;next</source>
        <translation>Nis &amp;pasuesin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Move &amp;down</source>
        <translation>Ule p&amp;oshtë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="835"/>
        <source>&amp;Remove entry</source>
        <translation>&amp;Hiqe zërin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="837"/>
        <source>Re&amp;set next</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>Change &amp;timeout</source>
        <translation>Ndryshoni &amp;mbarim kohe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="839"/>
        <source>Move &amp;up</source>
        <translation>Ngjite &amp;sipër</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="844"/>
        <location filename="../src/mainwindow.cpp" line="851"/>
        <source>not set, will boot using list order</source>
        <translation>e paujdisur, do të bëhet nisje duke përdorur radhën sipas listës</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="891"/>
        <source>Set &amp;inactive</source>
        <translation>Kaloje &amp;joaktiv  </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="970"/>
        <source>Failed to open grub.entry file.</source>
        <translation>S’u arrit të hapet kartela grub.entry.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1750"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Mjet për administrim zërash nisjeje UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <source>Both old and new EFI labels must be specified</source>
        <translation>Duhen treguar të dyja etiketa EFI, e vjetra dhe e reja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2001"/>
        <source>Multiple boot entries found for label &apos;%1&apos;: %2 and %3;</source>
        <translation>U gjetën zëra të shumtë për etiketën &apos;%1&apos;: %2 dhe %3;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2011"/>
        <source>No EFI data found for label &apos;%1&apos;.</source>
        <translation>S’u gjetën të dhëna EFI për etiketën &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2019"/>
        <source>EFI label &apos;%1&apos; is linked to an unknown partition &apos;%2&apos;.</source>
        <translation>Etiketa EFI &apos;%1&apos; është e lidhur me një pjesë të panjohur &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2030"/>
        <source>Unexpected device name format &apos;%1&apos; for partition related to the label.</source>
        <translation>Format i papritur emri pajisjeje &apos;%1&apos; për pjesën e lidhur me etiketën.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2040"/>
        <source>Device partition number [%1] differs from EFI entry partition number [%2].</source>
        <translation>Numri i pjesës së diskut [%1] është i ndryshëm nga numri i pjesës zë EFI [%2].</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2053"/>
        <source>Failed to delete old boot entry</source>
        <translation>S’u arrit të fshihet zë i vjetër nisjeje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2058"/>
        <source>Failed to create new boot entry</source>
        <translation>S’u arrit të krijohet zë i ri nisjeje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1585"/>
        <source>Failed to read grub.entry file.</source>
        <translation>S’u arrit të lexohet kartella grub.entry.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="955"/>
        <location filename="../src/mainwindow.cpp" line="1598"/>
        <source>Install</source>
        <translation>Instaloje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1604"/>
        <source>Select Frugal Directory</source>
        <translation>Përzgjidhni Drejtori Instalimi të Përkorë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1611"/>
        <source>No EFI System Partitions found.</source>
        <translation>S’u gjetën Pjesë EFI Sistemi.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1617"/>
        <source>Select EFI System Partition</source>
        <translation>Përzgjidhni Pjesë EFI Sistemi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1618"/>
        <source>EFI System Partitions:</source>
        <translation>Pjesë EFI Sistemi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1631"/>
        <source>No EFI System Partition selected</source>
        <translation>S’u përzgjodh Pjesë EFI Sistemi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1638"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>S’u montua dot Pjesë e përzgjedhur EFI Sistemi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1669"/>
        <location filename="../src/mainwindow.cpp" line="1713"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>S’u montua dot pjesë. Ju lutemi, sigurohuni se përzgjodhët pjesën e duhur.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1678"/>
        <source>No directory selected</source>
        <translation>S’u përzgjodh drejtori</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <location filename="../src/mainwindow.cpp" line="1735"/>
        <source>EFI stub installed successfully.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1700"/>
        <location filename="../src/mainwindow.cpp" line="1737"/>
        <source>Failed to install EFI stub.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1748"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1752"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Të drejta kopjimi (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1753"/>
        <source>%1 License</source>
        <translation>Licencë %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1761"/>
        <source>%1 Help</source>
        <translation>Ndihmë për %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1791"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Diç shkoi ters, s’u ruajt dot rend nisjeje.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Set timeout</source>
        <translation>Ujdisni mbarim kohe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Timeout in seconds:</source>
        <translation>Mbarim kohe, në sekonda:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Removal confirmation</source>
        <translation>Ripohim heqjeje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1842"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Jeni i sigurt se doni të fshihet ky zë nisjeje?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <source>License</source>
        <translation>Licencë</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Changelog</source>
        <translation>Regjistër ndryshimesh</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="125"/>
        <source>Error: Changelog file is missing.</source>
        <translation>Gabim: Mungon kartelë regjistri ndryshimesh.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="127"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>Gabim: Mungon mjet i domosdoshëm &apos;zless&apos;.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Mbylle</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>uefi-manager është një mjet për administrim zërash nisjeje UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>Përgjegjës UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation>Xhiro nën mënyrën provë (anashkalo pikasje UEFI për testim GUI).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>Ky sistem s’duket se mbulon UEFI, ose s’qe nisur nën mënyrën UEFI. Po dilet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Duket të jeni futur si rrënjë, ju lutemi, që të përdorni këtë program, dilni nga llogaria dhe hyni si përdorues i zakonshëm.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>version:</translation>
    </message>
</context>
</TS>