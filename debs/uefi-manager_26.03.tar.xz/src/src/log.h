/**********************************************************************
 *
 **********************************************************************
 * Copyright (C) 2024-2025 MX Authors
 *
 * Authors: Adrian <adrian@mxlinux.org>
 *          MX Linux <http://mxlinux.org>
 *
 * This is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package. If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/
#pragma once

#include <QDebug>
#include <QFile>
#include <QString>

#include "common.h"

class Log
{
public:
    explicit Log(const QString &fileName = LOG_FILE_PATH);
    static QString getLog();
    static void flush();
    [[nodiscard]] static bool hasRelevantContent(qsizetype minimumLineCount = 1);
    static void messageHandler(QtMsgType type, const QMessageLogContext &, const QString &msg);

private:
    inline static QFile logFile;
};
