<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sv">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="173"/>
        <source>Administrator Access Required</source>
        <translation>Administratörbehörighet krävs</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="174"/>
        <source>This operation requires administrator privileges.</source>
        <translation>Denna åtgärd kräver administratörbehörighet.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Var vänlig välj din installations plats:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Välj disk.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Välj partition:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Frugalt läge:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Boot-alternativ:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>UEFI post namn:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>UEFI hanterare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>EFI stub installerare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Kärna att boota:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Kärnalternativ:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>Om detta program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Avsluta programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Visa hjälp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Hantera UEFI poster</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Detta alternativ kopierar kärnan och initrd-filer till ESP (EFI System Partition) och skapar en UEFI post som gör det möjligt att boota installationen direkt, förbigå GRUB och andra bootloaders. För att boota med den skapade UEFI posten, gå till UEFI bootval-menyn vid start genom att trycka på korrekt tangent för din enhet (dvs, F12, F9, eller Esc, beroende på tillverkare).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>Frugal EFI stub installerare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Detta alternativ är avsett för att skapa en bootbar post förMX och antiX frugal installation, det skapar en EFI boot post för att starta installation direkt, förbigår GRUB och andra bootloaders. För att boota med den skapade UEFI posten, gå till UEFI bootvalsmeny vid start genom att trycka på rätt tangent för din enhet (d.v.s., F12, F9, eller Esc, beroende på tillverkare).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="1714"/>
        <source>Next</source>
        <translation>Nästa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Bakåt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="778"/>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <location filename="../src/mainwindow.cpp" line="1527"/>
        <location filename="../src/mainwindow.cpp" line="1537"/>
        <source>UEFI Installer</source>
        <translation>UEFI Installerare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="779"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>En färsk frugal installation har upptäckts. Vill du lägga till en UEFI post till din UEFI systemmeny?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Kunde inte få UUID för %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1033"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Skriv in lösenord för att låsa upp %1 krypterad partition:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1038"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>Lösenordspost borttagen eller tom för %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Kunde inte öppna %1 LUKS container</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1528"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>Är du säker på att detta är platsen för MX eller antiX Frugal installationen?
Saknar nödvändiga filer i katalog: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1592"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>Inte nog utrymme på EFI Systempartitionen för att kopiera kärnan och initrd filer.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1651"/>
        <source>All fields are required</source>
        <translation>Alla fält är nödvändiga</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1674"/>
        <source>Could not select ESP</source>
        <translation>Kunde inte välja ESP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1692"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Select EFI file</source>
        <translation>Välj EFI fil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>EFI filer (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <location filename="../src/mainwindow.cpp" line="212"/>
        <location filename="../src/mainwindow.cpp" line="219"/>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <location filename="../src/mainwindow.cpp" line="1038"/>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Kunde inte hitta källa till monteringspunkt för %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Set name</source>
        <translation>Ställ in namn</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Skriv in namnet för UEFI-meny posten:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="212"/>
        <source>Selected file is not in an EFI directory</source>
        <translation>Vald fil är inte i en EFI katalog</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="219"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Något blev fel, kunde inte lägga till posten.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <location filename="../src/mainwindow.cpp" line="1751"/>
        <source>Timeout: %1 seconds</source>
        <translation>Timeout: %1 sekunder</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <location filename="../src/mainwindow.cpp" line="859"/>
        <location filename="../src/mainwindow.cpp" line="1767"/>
        <source>Boot Next: %1</source>
        <translation>Nästa Boot: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="814"/>
        <source>Boot Current: %1</source>
        <translation>Boot Nuvarande: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Du kan använda Upp/Ner knapparna, eller drag &amp; släpp poster för att ändra boot ordning.
- Poster är listade i boot ordning.
- Grå rader är inaktiva.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="839"/>
        <location filename="../src/mainwindow.cpp" line="902"/>
        <source>Set ac&amp;tive</source>
        <translation>Gör ak&amp;tiv</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="840"/>
        <source>&amp;Add entry</source>
        <translation>&amp;Lägg till post</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="841"/>
        <source>Boot &amp;next</source>
        <translation>&amp;Nästa Boot </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="842"/>
        <source>Move &amp;down</source>
        <translation>Flytta ne&amp;r</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>&amp;Remove entry</source>
        <translation>Ta &amp;bort post</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>Re&amp;set next</source>
        <translation>&amp;Återställ nästa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="846"/>
        <source>Change &amp;timeout</source>
        <translation>Ändra ti&amp;meout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="847"/>
        <source>Move &amp;up</source>
        <translation>Flytta &amp;upp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <location filename="../src/mainwindow.cpp" line="859"/>
        <source>not set, will boot using list order</source>
        <translation>ej inställd, startar i listordning</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>Set &amp;inactive</source>
        <translation>Gör &amp;inaktiv</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <source>Failed to open grub.entry file.</source>
        <translation>Kunde inte öppna grub.entry filen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1695"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Verktyg för att hantera UEFI bootposter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1537"/>
        <source>Failed to read grub.entry file.</source>
        <translation>Kunde inte läsa grub.entry filen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="963"/>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <source>Install</source>
        <translation>Installera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1556"/>
        <source>Select Frugal Directory</source>
        <translation>Välj Frugal Katalog</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1563"/>
        <source>No EFI System Partitions found.</source>
        <translation>Inga EFI Systempartitioner hittade.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1568"/>
        <source>Select EFI System Partition</source>
        <translation>Välj EFI Systempartition</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1569"/>
        <source>EFI System Partitions:</source>
        <translation>EFI Systempartitioner:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1579"/>
        <source>No EFI System Partition selected</source>
        <translation>Ingen EFI Systempartition vald</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1586"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>Kunde inte montera vald EFI Systempartition</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1614"/>
        <location filename="../src/mainwindow.cpp" line="1658"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>Kunde inte montera partition. Var vänlig kontrollera att du valt rätt partition.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1623"/>
        <source>No directory selected</source>
        <translation>Ingen katalog vald</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1643"/>
        <location filename="../src/mainwindow.cpp" line="1680"/>
        <source>EFI stub installed successfully.</source>
        <translation>EFI stub installerades framgångsrikt.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1645"/>
        <location filename="../src/mainwindow.cpp" line="1682"/>
        <source>Failed to install EFI stub.</source>
        <translation>Kunde inte installera EFI stub.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1693"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1697"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <source>%1 License</source>
        <translation>%1 Licens</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>%1 Help</source>
        <translation>%1 Hjälp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Något blev fel, kunde inte spara boot-ordning.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1746"/>
        <source>Set timeout</source>
        <translation>Ställ in timeout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1746"/>
        <source>Timeout in seconds:</source>
        <translation>Timeout i sekunder:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1785"/>
        <source>Removal confirmation</source>
        <translation>Konfirmering av borttagande</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1786"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Är det säkert att du vill ta bort  denna boot post?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Changelog</source>
        <translation>Ändringslogg</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="102"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="126"/>
        <source>Error: Changelog file is missing.</source>
        <translation>Fel: Ändringsloggfilen saknas.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="128"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>Fel: Nödvändigt verktyg &apos;zless&apos; saknas.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="135"/>
        <source>&amp;Close</source>
        <translation>&amp;Stäng</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>uefi-hanterare är ett verktyg för att hantera UEFI boot poster</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation>Utför EFI Stub installation för frugal installation.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>UEFI Hanterare</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation>Kör i testläge (Förbigå UEFI detektion för GUI testning).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>Detta system verkar inte stödja UEFI, eller startades inte i UEFI läge. Avbryter.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du verkar vara inloggad som rot, var vänlig logga ut och logga in som vanlig användare för att använda detta program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>version:</translation>
    </message>
</context>
</TS>