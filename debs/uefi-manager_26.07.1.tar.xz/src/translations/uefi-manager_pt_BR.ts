<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt_BR">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="173"/>
        <source>Administrator Access Required</source>
        <translation>O acesso com as permissões de administrador é necessário</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="174"/>
        <source>This operation requires administrator privileges.</source>
        <translation>Esta operação requer privilégios de administrador.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Por favor, selecione o local que será realizada a sua instalação:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Selecionar a unidade:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Selecionar a partição:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Modo frugal:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Opções de inicialização:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>Nome da entrada do UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>Gerenciador do UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>Instalador do stub EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Kernel a ser inicializado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Opções do kernel:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>Sobre este programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Sair do programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Exibir a ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Gerenciar as entradas do UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Esta opção copia o kernel e arquivos ‘initrd’ para o Sistema de Partição EFI e cria uma entrada UEFI que permite iniciar a instalação diretamente, pulando o GRUB e outros inicializadores. Para iniciar o sistema a partir da entrada UEFI criada, acesse o menu de seleção da inicialização do UEFI durante a inicialização pressionando a tecla apropriada para a sua máquina, por exemplo, a tecla F2, F9, F12, Esc, Del, etc.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>Instalador do ‘stub’ EFI para o frugal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Esta opção permite criar uma entrada inicializável para a instalação frugal (econômica) do antiX Linux e do MX Linux. A entrada de inicialização do EFI possibilita iniciar a instalação diretamente, ignorando o GRUB e outros gerenciadores/carregadores de inicialização. Para inicializar a partir da entrada do UEFI que foi criada, acesse o menu de seleção da inicialização do UEFI durante a inicialização do seu equipamento pressionando a tecla apropriada, por exemplo, a tecla F2, F9, F12, Esc, Del ou Delete, etc.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="1714"/>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="778"/>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <location filename="../src/mainwindow.cpp" line="1527"/>
        <location filename="../src/mainwindow.cpp" line="1537"/>
        <source>UEFI Installer</source>
        <translation>Instalador do UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="779"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>Foi detectada uma instalação recente do tipo frugal. Você quer adicionar uma entrada diretamente no UEFI ao seu menu do sistema UEFI?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Não foi possível recuperar o UUID para o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1033"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Digite a senha para desbloquear a partição criptografada %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1038"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>A entrada da senha está vazia ou a ação foi cancelada para o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Não foi possível abrir o contêiner do LUKS %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1528"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>Você tem certeza de que este é o local da instalação frugal (econômica) do antiX Linux ou do MX Linux?
Os arquivos obrigatórios não estão presentes no diretório:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1592"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>Não há espaço suficiente na partição do sistema EFI para copiar os arquivos do ‘kernel‘ e do ‘initrd‘.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1651"/>
        <source>All fields are required</source>
        <translation>É obrigatório o preenchimento de todos os campos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1674"/>
        <source>Could not select ESP</source>
        <translation>Não foi possível selecionar a partição ESP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1692"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Select EFI file</source>
        <translation>Selecionar o arquivo EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>Arquivos EFI (*.efi ou *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <location filename="../src/mainwindow.cpp" line="212"/>
        <location filename="../src/mainwindow.cpp" line="219"/>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <location filename="../src/mainwindow.cpp" line="1038"/>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Error</source>
        <translation>Ocorreu um erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Não foi possível encontrar o ponto de montagem da origem para % 1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Set name</source>
        <translation>Nome do conjunto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Digite o nome do item para o menu do UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="212"/>
        <source>Selected file is not in an EFI directory</source>
        <translation>O arquivo selecionado não está num diretório EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="219"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Ocorreu um erro, não foi possível adicionar a entrada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <location filename="../src/mainwindow.cpp" line="1751"/>
        <source>Timeout: %1 seconds</source>
        <translation>Tempo limite em %1 segundos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <location filename="../src/mainwindow.cpp" line="859"/>
        <location filename="../src/mainwindow.cpp" line="1767"/>
        <source>Boot Next: %1</source>
        <translation>Inicializar em seguida %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="814"/>
        <source>Boot Current: %1</source>
        <translation>Inicialização atual % 1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Você pode utilizar as teclas para cima ou para baixo ou arrastar e soltar os itens para alterar a ordem de inicialização.
- Os itens são listados na ordem de inicialização.
- As linhas acinzentadas estão inativas.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="839"/>
        <location filename="../src/mainwindow.cpp" line="902"/>
        <source>Set ac&amp;tive</source>
        <translation>A&amp;tivar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="840"/>
        <source>&amp;Add entry</source>
        <translation>&amp;Adicionar uma entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="841"/>
        <source>Boot &amp;next</source>
        <translation>I&amp;nicializar em seguida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="842"/>
        <source>Move &amp;down</source>
        <translation>Mover para &amp;baixo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>&amp;Remove entry</source>
        <translation>&amp;Remover uma entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>Re&amp;set next</source>
        <translation>Re&amp;stabelecer o próximo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="846"/>
        <source>Change &amp;timeout</source>
        <translation>Alterar o &amp;tempo limite</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="847"/>
        <source>Move &amp;up</source>
        <translation>Mover para &amp;cima</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <location filename="../src/mainwindow.cpp" line="859"/>
        <source>not set, will boot using list order</source>
        <translation>Não foi definido, inicializará utilizando a ordem da lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>Set &amp;inactive</source>
        <translation>Definir como &amp;inativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <source>Failed to open grub.entry file.</source>
        <translation>Ocorreu uma falha ao abrir o arquivo ‘grub.entry’.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1695"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Ferramenta para gerenciar as entradas de inicialização do UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1537"/>
        <source>Failed to read grub.entry file.</source>
        <translation>Ocorreu uma falha ao ler o arquivo ‘grub.entry’.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="963"/>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1556"/>
        <source>Select Frugal Directory</source>
        <translation>Selecionar o diretório da instalação frugal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1563"/>
        <source>No EFI System Partitions found.</source>
        <translation>Nenhuma partição do sistema EFI foi encontrada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1568"/>
        <source>Select EFI System Partition</source>
        <translation>Selecionar a partição do sistema EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1569"/>
        <source>EFI System Partitions:</source>
        <translation>Partições do sistema EFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1579"/>
        <source>No EFI System Partition selected</source>
        <translation>Nenhuma partição do sistema EFI foi selecionada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1586"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>Não foi possível montar a partição selecionada do sistema EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1614"/>
        <location filename="../src/mainwindow.cpp" line="1658"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>Não foi possível montar a partição. Por favor, certifique-se de que você selecionou a partição correta.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1623"/>
        <source>No directory selected</source>
        <translation>Nenhum diretório foi selecionado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1643"/>
        <location filename="../src/mainwindow.cpp" line="1680"/>
        <source>EFI stub installed successfully.</source>
        <translation>O ‘stub’ da partição EFI foi instalado com sucesso.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1645"/>
        <location filename="../src/mainwindow.cpp" line="1682"/>
        <source>Failed to install EFI stub.</source>
        <translation>Ocorreu uma falha ao instalar o ‘stub’ na partição EFI.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1693"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1697"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de Autor (c) do MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Ocorreu um erro, não foi possível salvar a ordem de inicialização.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1746"/>
        <source>Set timeout</source>
        <translation>Configuração do tempo limite</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1746"/>
        <source>Timeout in seconds:</source>
        <translation>Tempo limite em segundos:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1785"/>
        <source>Removal confirmation</source>
        <translation>Confirmação de remoção</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1786"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Você tem certeza de que quer excluir esta entrada da inicialização?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Changelog</source>
        <translation>Relatório das Alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="102"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="126"/>
        <source>Error: Changelog file is missing.</source>
        <translation>Ocorreu um erro, porque o arquivo ‘changelog’ (registro de alterações) não está presente.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="128"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>Ocorreu um erro, porque o programa ‘zless’ que permite visualizar o conteúdo dos arquivos compactados não está presente.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="135"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>O gerenciador do UEFI é uma ferramenta que permite adicionar, excluir ou renomear as entradas de inicialização do UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation>Executar a instalação do ‘stub’ na partição EFI para uma instalação frugal.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>Gerenciador do UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation>Executar no modo de teste e ignora a detecção do UEFI para testes da interface gráfica.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>Ao que parece, este equipamento não é compatível com o UEFI ou não foi inicializado no modo UEFI. O programa será fechado.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Ocorreu um erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Ao que parece, você está conectado como usuário ‘root’ (administrador). Por favor, saia da sessão e entre novamente com o usuário normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>Versão:</translation>
    </message>
</context>
</TS>