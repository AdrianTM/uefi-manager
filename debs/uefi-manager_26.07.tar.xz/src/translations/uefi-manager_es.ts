<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="174"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="175"/>
        <source>This operation requires administrator privileges.</source>
        <translation>Esta operación requiere privilegios de administrador.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Por favor, seleccione la ubicación de su instalación:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Seleccionar unidad:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Seleccionar partición:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Modo frugal:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Opciones de arranque:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>Nombre de entrada UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>Gestor UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>Instalador EFI stub</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Kernel de arranque:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Opciones del kernel:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Gestionar entradas UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Esta opción copia los archivos del núcleo y de initrd a la ESP (partición del sistema EFI) y crea una entrada UEFI que permite arrancar la instalación directamente, sin pasar por GRUB ni otros gestores de arranque. Para arrancar utilizando la entrada UEFI creada, acceda al menú de selección de arranque UEFI al iniciar el sistema pulsando la tecla correspondiente a su dispositivo (p.ej., F12, F9 o Esc, dependiendo del fabricante).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>Instalador frugal de EFI stub</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Esta opción está pensada para crear una entrada de arranque para la instalación frugal de MX y antiX. Crea una entrada de arranque EFI para iniciar la instalación directamente, sin pasar por GRUB ni otros gestores de arranque. Para arrancar utilizando la entrada UEFI creada, acceda al menú de selección de arranque UEFI al iniciar el sistema pulsando la tecla correspondiente a su dispositivo (por ejemplo, F12, F9 o Esc, dependiendo del fabricante).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <location filename="../src/mainwindow.cpp" line="1804"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Volver</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="802"/>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <location filename="../src/mainwindow.cpp" line="1614"/>
        <location filename="../src/mainwindow.cpp" line="1624"/>
        <source>UEFI Installer</source>
        <translation>Instalador UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="803"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>Se ha detectado una instalación frugal reciente. ¿Desea añadir una entrada UEFI directamente a su menú de sistema UEFI?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>No se pudo recuperar el UUID para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1057"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Introduzca la contraseña para desbloquear la partición cifrada %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>Contraseña cancelada o vacía para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Could not open %1 LUKS container</source>
        <translation>No se pudo abrir contenedor LUKS %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1615"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>¿Está seguro que esta es la ubicación de la instalación frugal de MX o antiX?Faltan archivos obligatorios en el directorio: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1679"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>No hay suficiente espacio en la Partición EFI del Sistema para copiar los archivos kernel e initrd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>All fields are required</source>
        <translation>Todos los campos son obligatorios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1764"/>
        <source>Could not select ESP</source>
        <translation>No se pudo seleccionar ESP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1782"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>Select EFI file</source>
        <translation>Seleccionar archivo EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>Archivos EFI (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <location filename="../src/mainwindow.cpp" line="1826"/>
        <location filename="../src/mainwindow.cpp" line="1965"/>
        <location filename="../src/mainwindow.cpp" line="2036"/>
        <location filename="../src/mainwindow.cpp" line="2047"/>
        <location filename="../src/mainwindow.cpp" line="2054"/>
        <location filename="../src/mainwindow.cpp" line="2065"/>
        <location filename="../src/mainwindow.cpp" line="2075"/>
        <location filename="../src/mainwindow.cpp" line="2089"/>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>No se pudo encontrar el punto de montaje de origen para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Set name</source>
        <translation>Establecer nombre</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Ingrese el nombre para el elemento del menú UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Selected file is not in an EFI directory</source>
        <translation>El archivo seleccionado no se encuentra en un directorio EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Algo salió mal, no se pudo agregar la entrada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <location filename="../src/mainwindow.cpp" line="877"/>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Timeout: %1 seconds</source>
        <translation>Tiempo de espera: %1 segundos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="836"/>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <location filename="../src/mainwindow.cpp" line="1857"/>
        <source>Boot Next: %1</source>
        <translation>Arrancar siguiente: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>Boot Current: %1</source>
        <translation>Arranque actual: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Puede utilizar los botones Arriba/Abajo o arrastrar y soltar elementos para cambiar el orden de arranque.
- Los elementos se enlistan en el orden de arranque. 
- Las líneas atenuadas están inactivas.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <location filename="../src/mainwindow.cpp" line="926"/>
        <source>Set ac&amp;tive</source>
        <translation>Establecer ac&amp;tivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="864"/>
        <source>&amp;Add entry</source>
        <translation>&amp;Añadir entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="865"/>
        <source>Boot &amp;next</source>
        <translation>Arrancar &amp;siguiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="866"/>
        <source>Move &amp;down</source>
        <translation>Mover &amp;abajo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="867"/>
        <source>&amp;Remove entry</source>
        <translation>&amp;Remover entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="869"/>
        <source>Re&amp;set next</source>
        <translation>Re&amp;stablecer siguiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="870"/>
        <source>Change &amp;timeout</source>
        <translation>Cambiar &amp;tiempo de espera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="871"/>
        <source>Move &amp;up</source>
        <translation>Mover &amp;arriba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>not set, will boot using list order</source>
        <translation>no establecido, se iniciará usando el orden de la lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="923"/>
        <source>Set &amp;inactive</source>
        <translation>Establecer &amp;inactivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>Failed to open grub.entry file.</source>
        <translation>Error al abrir el archivo grub.entry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1785"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Herramienta para gestionar las entradas de arranque UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1965"/>
        <source>Both old and new EFI labels must be specified</source>
        <translation>Deben especificarse tanto las etiquetas EFI antiguas como las nuevas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2037"/>
        <source>Multiple boot entries found for label &apos;%1&apos;: %2 and %3;</source>
        <translation>Se han encontrado varias entradas de arranque para la etiqueta &apos;%1&apos;: %2 y %3;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2047"/>
        <source>No EFI data found for label &apos;%1&apos;.</source>
        <translation>No se encontraron datos EFI para la etiqueta &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2055"/>
        <source>EFI label &apos;%1&apos; is linked to an unknown partition &apos;%2&apos;.</source>
        <translation>La etiqueta EFI &apos;%1&apos; está vinculada a una partición desconocida &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2066"/>
        <source>Unexpected device name format &apos;%1&apos; for partition related to the label.</source>
        <translation>Formato de nombre de dispositivo inesperado &apos;%1&apos; para la partición relacionada con la etiqueta.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2076"/>
        <source>Device partition number [%1] differs from EFI entry partition number [%2].</source>
        <translation>El número de partición del dispositivo [%1] difiere del número de partición de entrada EFI [%2].</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2089"/>
        <source>Failed to delete old boot entry</source>
        <translation>Error al borrar la entrada de arranque antigua</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Failed to create new boot entry</source>
        <translation>Error al crear la nueva entrada de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1624"/>
        <source>Failed to read grub.entry file.</source>
        <translation>Error al leer el archivo grub.entry.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="987"/>
        <location filename="../src/mainwindow.cpp" line="1637"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1643"/>
        <source>Select Frugal Directory</source>
        <translation>Seleccionar directorio frugal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1650"/>
        <source>No EFI System Partitions found.</source>
        <translation>No se encontró ninguna partición del sistema EFI.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1655"/>
        <source>Select EFI System Partition</source>
        <translation>Seleccionar la partición del sistema EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>EFI System Partitions:</source>
        <translation>Particiones del sistema EFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1666"/>
        <source>No EFI System Partition selected</source>
        <translation>No seleccionó la partición del sistema EFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1673"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>No se pudo montar la partición del sistema EFI seleccionada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1704"/>
        <location filename="../src/mainwindow.cpp" line="1748"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>No se pudo montar la partición. Asegúrese de haber seleccionado la partición correcta.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1713"/>
        <source>No directory selected</source>
        <translation>Ningún directorio seleccionado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1733"/>
        <location filename="../src/mainwindow.cpp" line="1770"/>
        <source>EFI stub installed successfully.</source>
        <translation>EFI stub se ha instalado correctamente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1735"/>
        <location filename="../src/mainwindow.cpp" line="1772"/>
        <source>Failed to install EFI stub.</source>
        <translation>Error al instalar EFI stub.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1783"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1787"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1788"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1796"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1826"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Algo salió mal, no se pudo guardar el orden de inicio.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Set timeout</source>
        <translation>Establecer tiempo de espera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Timeout in seconds:</source>
        <translation>Tiempo de espera en segundos:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1875"/>
        <source>Removal confirmation</source>
        <translation>Confirmación de eliminación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1876"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>¿Está seguro de que desea eliminar esta entrada de arranque?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="125"/>
        <source>Error: Changelog file is missing.</source>
        <translation>Error: Falta el archivo de registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="127"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>Error: Falta la utilidad requerida &quot;zless»&quot;</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>uefi-manager es una herramienta para gestionar las entradas de arranque UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation>Realizar la instalación EFI Stub para una instalación frugal.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>Gestor UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation>Ejecutar en modo de prueba (omitir la detección UEFI para pruebas GUI).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>Este sistema no parece soportar UEFI, o no fue arrancado en modo UEFI. Saliendo.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>versión:</translation>
    </message>
</context>
</TS>