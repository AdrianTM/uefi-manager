<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nb">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="174"/>
        <source>Administrator Access Required</source>
        <translation>Administratortilgang kreves</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="175"/>
        <source>This operation requires administrator privileges.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Velg hvor systemet er installert:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Velg disk:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Velg partisjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Nøysom modus:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Oppstartsalternativer:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>Menynavn for UEFI:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>UEFI-behandling</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>Installering av EFI-stubb</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Start denne kjernen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Alternativer for kjernen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>Om programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>Om …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt + B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Avslutt programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt + N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Vis hjelp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Behandle UEFI-oppføringer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>Nøysom installering av EFI-stubb</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>Dette alternativet lager et oppstartsvalg for nøysom installering av MX og antiX. Det lager en oppføring i EFI slik at installeringen kan starte direkte uten GRUB eller andre oppstartslastere. For å finne denne UEFI-oppføringen, må en få opp oppstartsmenyen ved å trykke på riktig knapp for din enhet (f.eks. F12, F9 eller ESC, avhengig av leverandør).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt + H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <location filename="../src/mainwindow.cpp" line="1804"/>
        <source>Next</source>
        <translation>Neste</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Tilbake</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="802"/>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <location filename="../src/mainwindow.cpp" line="1614"/>
        <location filename="../src/mainwindow.cpp" line="1624"/>
        <source>UEFI Installer</source>
        <translation>UEFI-installering</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="803"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>Oppdaget en nylig nøysom installasjon. Vil du legge til en UEFI-oppføring i systemmenyen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Klarte ikke hente UUID for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1057"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Angi passfrase for å låse opp den krypterte partisjonen %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>Skriving av passfrase ble avbrutt eller er tom for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Klarte ikke åpne %1 LUKS-partisjon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1615"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>Er du sikker på at dette er plasseringen til en nøysom MX- eller antiX-installasjon?
Det mangler noen obligatoriske filer i mappa:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1679"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>Det er ikke nok diskplass på EFI systempartisjon til å kopiere kjernen og initrd-filene.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>All fields are required</source>
        <translation>Alle feltene er påkrevd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1764"/>
        <source>Could not select ESP</source>
        <translation>Klarte ikke velge ESP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1782"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>Select EFI file</source>
        <translation>Velg EFI-fil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>EFI-filer (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <location filename="../src/mainwindow.cpp" line="1826"/>
        <location filename="../src/mainwindow.cpp" line="1965"/>
        <location filename="../src/mainwindow.cpp" line="2036"/>
        <location filename="../src/mainwindow.cpp" line="2047"/>
        <location filename="../src/mainwindow.cpp" line="2054"/>
        <location filename="../src/mainwindow.cpp" line="2065"/>
        <location filename="../src/mainwindow.cpp" line="2075"/>
        <location filename="../src/mainwindow.cpp" line="2089"/>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Fant ikke monteringspunkt på kilden for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Set name</source>
        <translation>Velg navn</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Velg navn for UEFI-element i menyen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Selected file is not in an EFI directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Noe gikk galt, klarte ikke legge til element.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <location filename="../src/mainwindow.cpp" line="877"/>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Timeout: %1 seconds</source>
        <translation>Tidsavbrudd: %1 sekunder</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="836"/>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <location filename="../src/mainwindow.cpp" line="1857"/>
        <source>Boot Next: %1</source>
        <translation>Neste oppstart: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>Boot Current: %1</source>
        <translation>Gjeldende oppstart: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Bruk piltastene Opp/Ned eller dra og slipp for å endre oppstartsrekkefølgen.
- Elementene er listet opp i oppstartsrekkefølge.
- Grå linjer er ikke aktive.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <location filename="../src/mainwindow.cpp" line="926"/>
        <source>Set ac&amp;tive</source>
        <translation>Velg ak&amp;tiv</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="864"/>
        <source>&amp;Add entry</source>
        <translation>Legg til oppf&amp;øring</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="865"/>
        <source>Boot &amp;next</source>
        <translation>&amp;Neste oppstart</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="866"/>
        <source>Move &amp;down</source>
        <translation>Flytt ne&amp;d</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="867"/>
        <source>&amp;Remove entry</source>
        <translation>Fje&amp;rn oppføring</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="869"/>
        <source>Re&amp;set next</source>
        <translation>Tilbake&amp;still neste</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="870"/>
        <source>Change &amp;timeout</source>
        <translation>Endre &amp;tidsavbrudd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="871"/>
        <source>Move &amp;up</source>
        <translation>Fl&amp;ytt opp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>not set, will boot using list order</source>
        <translation>ikke valgt, vil starte med rekkefølge som i lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="923"/>
        <source>Set &amp;inactive</source>
        <translation>Velg &amp;inaktiv</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>Failed to open grub.entry file.</source>
        <translation>Klarte ikke åpne grub.entry-filen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1785"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Verktøy for behandling av oppstartsoppføringer i UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1965"/>
        <source>Both old and new EFI labels must be specified</source>
        <translation>Både gamle og nye EFI-disknavn må angis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2037"/>
        <source>Multiple boot entries found for label &apos;%1&apos;: %2 and %3;</source>
        <translation>Fant flere oppstartsoppføringer for disknavnet «%1»: %2 og %3;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2047"/>
        <source>No EFI data found for label &apos;%1&apos;.</source>
        <translation>Fant ingen EFI-data for disknavnet «%1».</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2055"/>
        <source>EFI label &apos;%1&apos; is linked to an unknown partition &apos;%2&apos;.</source>
        <translation>EFI-disknavnet «%1» er koblet til en ukjent partisjon «%2».</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2066"/>
        <source>Unexpected device name format &apos;%1&apos; for partition related to the label.</source>
        <translation>Uventet format på enhetsnavnet «%1» for partisjonen knyttet til disknavnet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2076"/>
        <source>Device partition number [%1] differs from EFI entry partition number [%2].</source>
        <translation>Enhetens partisjonsnummer [%1] avviker fra EFI-oppføringens partisjonsnummer [%2].</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2089"/>
        <source>Failed to delete old boot entry</source>
        <translation>Klarte ikke slette gammel oppstartsoppføring</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Failed to create new boot entry</source>
        <translation>Klarte ikke opprette ny oppstartsoppføring</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1624"/>
        <source>Failed to read grub.entry file.</source>
        <translation>Klarte ikke lese grub.entry-filen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="987"/>
        <location filename="../src/mainwindow.cpp" line="1637"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1643"/>
        <source>Select Frugal Directory</source>
        <translation>Velg nøysom-mappa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1650"/>
        <source>No EFI System Partitions found.</source>
        <translation>Fant ikke EFI-systempartisjon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1655"/>
        <source>Select EFI System Partition</source>
        <translation>Velg EFI-systempartisjon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>EFI System Partitions:</source>
        <translation>EFI-systempartisjoner:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1666"/>
        <source>No EFI System Partition selected</source>
        <translation>Ingen EFI-systempartisjoner er valgt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1673"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>Klarte ikke montere valgt EFI-systempartisjon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1704"/>
        <location filename="../src/mainwindow.cpp" line="1748"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>Klarte ikke montere partisjon. Sørg for at du har valgt riktig partisjon.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1713"/>
        <source>No directory selected</source>
        <translation>Ingen mappe er valgt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1733"/>
        <location filename="../src/mainwindow.cpp" line="1770"/>
        <source>EFI stub installed successfully.</source>
        <translation>EFI-stubben ble riktig installert.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1735"/>
        <location filename="../src/mainwindow.cpp" line="1772"/>
        <source>Failed to install EFI stub.</source>
        <translation>Klarte ikke installere EFI-stubb.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1783"/>
        <source>Version: </source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1787"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Opphavsrett (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1788"/>
        <source>%1 License</source>
        <translation>Lisens for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1796"/>
        <source>%1 Help</source>
        <translation>Hjelpetekst for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1826"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Noe gikk galt, klarte ikke lagre oppstartsrekkefølge.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Set timeout</source>
        <translation>Velg tidsavbrudd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Timeout in seconds:</source>
        <translation>Tidsavbrudd i sekunder:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1875"/>
        <source>Removal confirmation</source>
        <translation>Bekreft fjerning</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1876"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Vil du virkelig slette denne oppføringen?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <source>License</source>
        <translation>Lisens</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Changelog</source>
        <translation>Endringslogg</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="125"/>
        <source>Error: Changelog file is missing.</source>
        <translation>Feil: Fil med endringslogg mangler.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="127"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>Feil: Påkrevd verktøy &apos;zless&apos; mangler.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>uefi-manager er et verktøy for behandling av oppstartsoppføringer i UEFI</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation>Installer EFI-stubb for nøysom modus.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>UEFI-behandling</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation>Kjør i testmodus (hopp over UEFI-deteksjon for testing av grafisk brukergrensesnitt).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>Dette systemet støtter ikke UEFI, eller ble ikke startet i UEFI-modus. Avslutter.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du er innlogget som root. Vennligst logg ut, og logg inn igjen som en vanlig bruker for å bruke dette programmet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>versjon:</translation>
    </message>
</context>
</TS>