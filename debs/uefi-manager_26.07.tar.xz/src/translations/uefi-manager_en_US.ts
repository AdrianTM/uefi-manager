<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="en_US">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="174"/>
        <source>Administrator Access Required</source>
        <translation>Administrator Access Required</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="175"/>
        <source>This operation requires administrator privileges.</source>
        <translation>This operation requires administrator privileges.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>Please select the location of your installation:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>Select drive:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>Select partition:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>Frugal mode:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>Boot options:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>UEFI entry name:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>UEFI manager</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>EFI stub installer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>Kernel to boot:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>Kernel options:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>About this application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>About...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>Quit application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>Display help </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>Manage UEFI entries</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>Frugal EFI stub installer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <location filename="../src/mainwindow.cpp" line="1804"/>
        <source>Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>Back</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="802"/>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <location filename="../src/mainwindow.cpp" line="1614"/>
        <location filename="../src/mainwindow.cpp" line="1624"/>
        <source>UEFI Installer</source>
        <translation>UEFI Installer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="803"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Could not retrieve UUID for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1057"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>Enter passphrase to unlock %1 encrypted partition:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>Passphrase entry cancelled or empty for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Could not open %1 LUKS container</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1615"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1679"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>Not enough space on the EFI System Partition to copy the kernel and initrd files.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>All fields are required</source>
        <translation>All fields are required</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1764"/>
        <source>Could not select ESP</source>
        <translation>Could not select ESP</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1782"/>
        <source>About %1</source>
        <translation>About %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>Select EFI file</source>
        <translation>Select EFI file</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>EFI files (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <location filename="../src/mainwindow.cpp" line="1826"/>
        <location filename="../src/mainwindow.cpp" line="1965"/>
        <location filename="../src/mainwindow.cpp" line="2036"/>
        <location filename="../src/mainwindow.cpp" line="2047"/>
        <location filename="../src/mainwindow.cpp" line="2054"/>
        <location filename="../src/mainwindow.cpp" line="2065"/>
        <location filename="../src/mainwindow.cpp" line="2075"/>
        <location filename="../src/mainwindow.cpp" line="2089"/>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Error</source>
        <translation>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="184"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Could not find the source mountpoint for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Set name</source>
        <translation>Set name</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Enter the name for the UEFI menu item:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Selected file is not in an EFI directory</source>
        <translation>Selected file is not in an EFI directory</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Something went wrong, could not add entry.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <location filename="../src/mainwindow.cpp" line="877"/>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Timeout: %1 seconds</source>
        <translation>Timeout: %1 seconds</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="836"/>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <location filename="../src/mainwindow.cpp" line="1857"/>
        <source>Boot Next: %1</source>
        <translation>Boot Next: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>Boot Current: %1</source>
        <translation>Boot Current: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <location filename="../src/mainwindow.cpp" line="926"/>
        <source>Set ac&amp;tive</source>
        <translation>Set ac&amp;tive</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="864"/>
        <source>&amp;Add entry</source>
        <translation>&amp;Add entry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="865"/>
        <source>Boot &amp;next</source>
        <translation>Boot &amp;next</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="866"/>
        <source>Move &amp;down</source>
        <translation>Move &amp;down</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="867"/>
        <source>&amp;Remove entry</source>
        <translation>&amp;Remove entry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="869"/>
        <source>Re&amp;set next</source>
        <translation>Re&amp;set next</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="870"/>
        <source>Change &amp;timeout</source>
        <translation>Change &amp;timeout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="871"/>
        <source>Move &amp;up</source>
        <translation>Move &amp;up</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <location filename="../src/mainwindow.cpp" line="883"/>
        <source>not set, will boot using list order</source>
        <translation>not set, will boot using list order</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="923"/>
        <source>Set &amp;inactive</source>
        <translation>Set &amp;inactive</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1002"/>
        <source>Failed to open grub.entry file.</source>
        <translation>Failed to open grub.entry file.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1785"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>Tool for managing UEFI boot entries</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1965"/>
        <source>Both old and new EFI labels must be specified</source>
        <translation>Both old and new EFI labels must be specified</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2037"/>
        <source>Multiple boot entries found for label &apos;%1&apos;: %2 and %3;</source>
        <translation>Multiple boot entries found for label &apos;%1&apos;: %2 and %3;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2047"/>
        <source>No EFI data found for label &apos;%1&apos;.</source>
        <translation>No EFI data found for label &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2055"/>
        <source>EFI label &apos;%1&apos; is linked to an unknown partition &apos;%2&apos;.</source>
        <translation>EFI label &apos;%1&apos; is linked to an unknown partition &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2066"/>
        <source>Unexpected device name format &apos;%1&apos; for partition related to the label.</source>
        <translation>Unexpected device name format &apos;%1&apos; for partition related to the label.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2076"/>
        <source>Device partition number [%1] differs from EFI entry partition number [%2].</source>
        <translation>Device partition number [%1] differs from EFI entry partition number [%2].</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2089"/>
        <source>Failed to delete old boot entry</source>
        <translation>Failed to delete old boot entry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Failed to create new boot entry</source>
        <translation>Failed to create new boot entry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1624"/>
        <source>Failed to read grub.entry file.</source>
        <translation>Failed to read grub.entry file.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="987"/>
        <location filename="../src/mainwindow.cpp" line="1637"/>
        <source>Install</source>
        <translation>Install</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1643"/>
        <source>Select Frugal Directory</source>
        <translation>Select Frugal Directory</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1650"/>
        <source>No EFI System Partitions found.</source>
        <translation>No EFI System Partitions found.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1655"/>
        <source>Select EFI System Partition</source>
        <translation>Select EFI System Partition</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>EFI System Partitions:</source>
        <translation>EFI System Partitions:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1666"/>
        <source>No EFI System Partition selected</source>
        <translation>No EFI System Partition selected</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1673"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>Could not mount selected EFI System Partition</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1704"/>
        <location filename="../src/mainwindow.cpp" line="1748"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>Could not mount partition. Please make sure you selected the correct partition.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1713"/>
        <source>No directory selected</source>
        <translation>No directory selected</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1733"/>
        <location filename="../src/mainwindow.cpp" line="1770"/>
        <source>EFI stub installed successfully.</source>
        <translation>EFI stub installed successfully.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1735"/>
        <location filename="../src/mainwindow.cpp" line="1772"/>
        <source>Failed to install EFI stub.</source>
        <translation>Failed to install EFI stub.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1783"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1787"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1788"/>
        <source>%1 License</source>
        <translation>%1 License</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1796"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1826"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Something went wrong, could not save boot order.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Set timeout</source>
        <translation>Set timeout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Timeout in seconds:</source>
        <translation>Timeout in seconds:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1875"/>
        <source>Removal confirmation</source>
        <translation>Removal confirmation</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1876"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Are you sure you want to delete this boot entry?
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <source>License</source>
        <translation>License</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="125"/>
        <source>Error: Changelog file is missing.</source>
        <translation>Error: Changelog file is missing.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="127"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>Error: Required utility &apos;zless&apos; is missing.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Close</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>uefi-manager is a tool for managing UEFI boot entries</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation>Perform EFI Stub installation for frugal installation.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>UEFI Manager</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation>Run in test mode (bypass UEFI detection for GUI testing).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>You seem to be logged in as root, please log out and log in as normal user to use this program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>version:</translation>
    </message>
</context>
</TS>