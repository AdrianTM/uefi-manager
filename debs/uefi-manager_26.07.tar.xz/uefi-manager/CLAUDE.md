# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build Commands

**Primary build system (CMake with Ninja):**
```bash
./build.sh              # Release build
./build.sh --debug       # Debug build
./build.sh --clang       # Use clang compiler
./build.sh --clean       # Clean before building
./build.sh --debian      # Build Debian package
./build.sh --arch        # Build Arch Linux package
```

**Manual CMake build:**
```bash
mkdir -p build
cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
```

**Run application:**
```bash
./build/uefi-manager           # Normal mode
./build/uefi-manager --test    # Test mode (bypass UEFI detection)
./build/uefi-manager --frugal  # Frugal installation mode
./build/uefi-manager --help    # Show help
```

**Testing on non-UEFI systems:**
Use the `--test` flag to bypass UEFI detection and run the GUI for development/testing purposes.

## Architecture Overview

UEFI Manager is a Qt6 application for managing UEFI boot entries on Linux systems.

### Core Components

- **MainWindow**: Primary UI controller with tabbed interface for boot entries, EFI stub installation, and frugal installations
- **Cmd**: Process execution wrapper that handles both regular and elevated (root) command execution using pkexec
- **Log**: Logging facility for application events
- **About**: Standard about dialog

### Key Architecture Patterns

- **Privileged Operations**: Uses pkexec via helper scripts in `scripts/` directory for root-level operations
- **Multi-tab UI**: Three main tabs (Entries, StubInstall, Frugal) with wizard-style navigation
- **Device Detection**: Automatically detects UEFI support, partitions, and boot configurations via `/sys/firmware/efi/efivars`
- **Translation Support**: Full internationalization with Qt translation system

### File Structure

- Main application code in `src/` directory (`.cpp`, `.h`, `.ui` files)
- Helper scripts in `scripts/` for privileged operations
- Translations in `translations/` and `translations-desktop-file/`
- Debian packaging in `debian/`
- CMake build system with Ninja generator support

### Dependencies

- Qt6 (Core, GUI, Widgets, LinguistTools modules)
- C++20 standard
- System utilities: efibootmgr, grub tools, cryptsetup, lsblk, blkid
- Root privileges via pkexec for UEFI modifications

### Build Configuration

- Uses CMake build system with Qt6 (Core, GUI, Widgets modules)
- Supports debug/release configurations with LTO optimization in release mode
- Strict compiler warnings enabled (-Werror for critical warnings)
- C++20 standard required
- Application version extracted from `debian/changelog`
- Ninja generator preferred for faster builds

### Development Workflow

- Main application logic in `src/mainwindow.cpp` with UI defined in `src/mainwindow.ui`
- Command execution wrapper in `src/cmd.cpp` handles both regular and elevated operations
- Privileged operations use `scripts/helper` via pkexec for security
- UI is internationalized with `.ts` translation files in `translations/`
- Build outputs to `build/` directory with separate debug/release configurations

### Security Model

- Root privileges required for UEFI modifications via efibootmgr
- Uses PolicyKit/pkexec for secure privilege escalation
- Helper script (`scripts/helper`) executes privileged commands
- Policy file (`scripts/org.mxlinux.pkexec.mx-uefimanager-helper.policy`) defines permissions for root operations
- UEFI detection can be bypassed with `--test` flag for development on non-UEFI systems

### Key Features

- **Boot Entry Management**: View, add, remove, reorder UEFI boot entries
- **EFI Stub Installation**: Direct kernel boot bypassing bootloaders
- **Frugal Installation Support**: Specialized support for MX/antiX frugal installations
- **Partition Detection**: Automatic ESP and Linux partition discovery
- **LUKS Support**: Encrypted partition mounting and access

### Packaging

**Debian/Ubuntu:**
- Packaging files in `debian/` directory
- Version extracted from `debian/changelog`
- Build packages with `./build.sh --debian`
- Outputs to `debs/` directory

**Arch Linux:**
- PKGBUILD file in repository root
- Build packages with `./build.sh --arch`
- Uses `makepkg` for package creation
- Version synchronized from `debian/changelog`