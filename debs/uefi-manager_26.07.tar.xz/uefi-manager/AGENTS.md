# Repository Guidelines

## Project Structure & Module Organization
- `src/` hosts Qt6 widget sources covering the main window, logging, and command helpers.
- `scripts/` supplies packaging and integration utilities; run them from the repository root.
- `debian/` tracks packaging metadata; `release/` and `debug/` hold staged installers and symbols.
- `translations/` and `translations-desktop-file/` store `.ts` catalogs; rerun `./build.sh` to regenerate `.qm` files.
- `images/` and root icons feed `images.qrc` for bundling with the application.

## Build, Test, and Development Commands
- `./build.sh` creates a Release build in `build/` with warnings treated as errors.
- `./build.sh --debug` enables debug flags and verbose logging for troubleshooting.
- `./build.sh --clang` switches to Clang; ensure the toolchain is installed locally.
- `./build.sh --clean` removes cached configuration before re-running a build.
- `cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel` performs manual configure and build cycles.
- `./build/uefi-manager` launches the GUI; set `QT_QPA_PLATFORM` for alternate display stacks.

## Coding Style & Naming Conventions
- Target C++20, treat warnings as errors, and prefer Qt types in the UI with STL helpers elsewhere.
- Include `#pragma once`, order Qt headers before project headers, and forward declare where practical.
- Name classes in PascalCase, functions and variables in camelCase, and constants in UPPER_CASE.
- Indent with four spaces, keep braces on the same line, and strip trailing whitespace before committing.
- Lean on RAII and Qt parent-child ownership; mark getters `[[nodiscard]]` and use `enum class` for scoped enumerations.

## Testing Guidelines
- No automated suite exists yet; build Release and Debug variants and run `./build/uefi-manager` for validation.
- Exercise UEFI paths on safe hardware or virtual firmware, ensuring `pkexec` prompts appear only for privileged actions.
- After localization edits, rebuild to refresh `.qm` files and smoke-test under alternate locales.

## Commit & Pull Request Guidelines
- Write commit subjects as concise passive summaries under 72 characters (e.g., `Device list refresh logic adjusted`).
- Keep commits focused; reference related issues or modules in the body when it adds clarity.
- Pull requests should describe the problem, implemented solution, and verification commands; attach UI screenshots for visible changes.
- Confirm formatting, translation regeneration, and absence of trailing whitespace before requesting review.

## Security & Privileged Operations
- Firmware changes go through `pkexec`; never bypass authorization or embed unsanitized commands.
- Guard privileged paths during development and audit packaging scripts for secrets.
